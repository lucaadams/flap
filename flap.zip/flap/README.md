# How to play
1. Open the "Release" folder
2. Double click on the "flap" or "flap.exe" file